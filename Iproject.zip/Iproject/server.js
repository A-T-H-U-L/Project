const express=require('express');
const app= express();
const jwt=require('jsonwebtoken');
require('dotenv').config()
const mysql = require("mysql")
const bodyParser = require("body-parser");
var cors = require('cors')


var urlencodedParser = bodyParser.urlencoded({ extended: false })

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

app.listen(3000);
app.use(express.json())



var cors = require('cors')

app.use(cors())

const posts=[{
    username:"athul",
    password:"athul1"
},
{
    username:"arun",
    password:"arun1"
}]

/*--------------------------------------------*/
// sql connection
let con = mysql.createConnection({

    host: 'localhost',

    user: 'root',

    password: 'password',

    database: 'taxproject_db'

});

 

con.connect((err) => {

    if (err) {

        return console.error('error: ' + err.message);

    }

 

    console.log('Connected to the MySQL server.');

});
/*--------------------------------------------*/





app.get('/posts',authenticateToken,(req,res)=>{
    res.json(posts.filter(post))
})

app.post('/login',(req,res)=>{
    const username=req.body.username;
    const password = req.body.password;
    if(req.body.username == undefined || req.body.password == undefined) {

        console.log("error");

        res.status(500).send({ error: "autentication failed" });

    }

    let query = `select name from users  where username = '${username}' and  password =  '${password}'   `

    // let username = req.body.username;

    // 
   

    // Authenticate the user
  
  const user={
              uname:username,
              pword: password
              }
  const accessToken=jwt.sign(user,process.env.ACCESS_TOKEN_SECERET)
  res.json({accessToken:accessToken})

})

//Registration

app.post('/registration', urlencodedParser,(req,res)=>{
  
    const mail=req.body.email;
  
    console.clear()
  
    console.log(req.body.name)
  
    const pswd=req.body.password;
    const name= req.body.name;
  
  
  
   let query   = `INSERT INTO users (username,password,name) VALUES ("${mail}", "${pswd}", "${name}")`;
  
    connection.query(query,(err,result)=>{
  
      if(err) throw err
  
      res.json(result)
  
    })
  })




// middileware for verification
function authenticateToken(req,res,next){
    const authHeader= req.headers['authorization']
    const token =authHeader && authHeader.split(' ')[1]
    if(token== null) return res.sendStatus(401)
    
    jwt.verify(token, process.env.ACCESS_TOKEN_SECERET,(err,user=>{
        if(err)return res.sendStatus(403)
        req.user=user
        next()
    }))
}