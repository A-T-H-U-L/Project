let yourName=document.getElementById("name");

let email=document.getElementById("email");

let password=document.getElementById("password");

let confirmPassword=document.getElementById("confirm-password")

yourName.addEventListener("input",()=>{

    if(yourName.value.length<=3){

        yourName.style.border="2px solid red";

    }

    else{

        yourName.style.border="2px solid green"

    }

})

email.addEventListener("input",()=>{

    var emailFilter = /^[^@]+@[^@.]+\.[^@]*\w\w$/;

    if(email.value.length>=3 && emailFilter.test(email.value)){

        email.style.border="2px solid green";

       

    }

    else{

        email.style.border="2px solid red";

    }

})

password.addEventListener("input",()=>{

  var passwordRegx= /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

  if(passwordRegx.test(password.value)){

      password.style.border="2px solid green";

  }

  else{

      password.style.border="2px solid red";

  }

})

confirmPassword.addEventListener("input",()=>{

    if(confirmPassword.value==password.value){

        confirmPassword.style.border="2px solid green";

    }

    else{

        confirmPassword.style.border="2px solid red";

    }

})