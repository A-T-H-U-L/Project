let mysql = require('mysql');
const express=require('express');
const app=express();
const bodyParser = require("body-parser"); 
var cors = require('cors')
var passport=require('passport');

app.use(cors())
var urlencodedParser = bodyParser.urlencoded({ extended: false }) 
app.use(bodyParser.urlencoded({ extended: false })); 
app.use(bodyParser.json());
let connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'employeedb'
});
connection.connect((err)=> {
    if (err) {
      return console.error('error: ' + err.message);
    }
  
    console.log('Connected to the MySQL server.');
  });

  connection.query('select * from employeedetails; ', 
      function (err, result) {
        if(err)
          console.log(`Error executing the query - ${err}`)
        else
          console.log("Result: ",result) 
      })
  


      //EmployeeDetails

      app.get('/getemp',(req,res)=>{
connection.query('select * from employeedetails;',(err,result)=>{
    res.json(result)
})
      })

      app.get('/getemp/:id',(req,res)=>{
        connection.query('select * from employeedetails WHERE id=?',[req.params.id],(err,result)=>{
            res.json(result)
        })
              })

app.post('/addemp', urlencodedParser,(req,res)=>{

        console.log(req.body.name)

       

        const emp_name=req.body.name;

        console.clear()

        console.log(req.body.name)

        const emp_account=req.body.account;

        const emp_salary=req.body.salary;

        const emp_project=req.body.project;

        const emp_gender=req.body.gender;

   

       let query   = `INSERT INTO employeedetails ( name, account, salary, project,gender) VALUES ("${emp_name}", "${emp_account}", "${emp_salary}", "${emp_project}","${emp_gender}")`;

        connection.query(query,(err,result)=>{

          if(err) throw err

          res.json(result)

        })



      })

      app.put('/update/:id',urlencodedParser,(req,res)=>{

        const upId=req.params.id;

        console.log(req.body.name)

        let emp_name=req.body.name;

        const emp_account=req.body.account;

        const emp_salary=req.body.salary;

        const emp_project=req.body.project;

        const emp_gender=req.body.gender;

          connection.query("UPDATE employeedetails SET ? WHERE id=?;",[{name:emp_name,account:emp_account,salary:emp_salary,project:emp_project,gender:emp_gender},upId],(err,result)=>{

            if(err){

                console.log(err)}

                else{

                    res.send("updated")}

                    console.log(result)

            })

          })
        

      app.delete('/delete/:id',(req,res)=>{
          const deletId=req.params.id;

          connection.query("delete from employeedetails where id=?;",deletId,(err,result)=>{
              if(err){
                  console.log(err)}
                  else{
                      res.send("DELETED")}
                      console.log(result)
              })
        //   res.json(result)
      })



//registration



app.post('/registration', urlencodedParser,(req,res)=>{
  
  const emp_mail=req.body.email;

  console.clear()

  console.log(req.body.name)

  const emp_password=req.body.password;
  const emp_name= req.body.name;



 let query   = `INSERT INTO registration ( email, password,name) VALUES ("${emp_mail}", "${emp_password}", "${emp_name}")`;

  connection.query(query,(err,result)=>{

    if(err) throw err

    res.json(result)

  })
})

// process the login form
// app.post('/test', passport.authenticate('local-login', {
//   successRedirect : '/profile', // redirect to the secure profile section
//   failureRedirect : '/login', // redirect back to the signup page if there is an error
//   failureFlash : true // allow flash messages
// }),
// function(req, res) {
//   console.log("hello");

//   if (req.body.remember) {
//     req.session.cookie.maxAge = 1000 * 60 * 3;
//   } else {
//     req.session.cookie.expires = false;
//   }
// res.redirect('/');
// });

      //ProjectDetails
      app.get('/getproject',(req,res)=>{
        connection.query('select * from projectdetails;',(err,result)=>{
            res.json(result)
        })
              })
        
              // app.get('/getproject/:id',(req,res)=>{
              //   connection.query('select * from projectdetails WHERE id=?',[req.params.id],(err,result)=>{
              //       res.json(result)
              //   })
              //         })
    



              app.post('/addproject', urlencodedParser,(req,res)=>{

                console.log(req.body.name)
        
               
        
                const emp_id=req.body.id;
        
                // console.clear()
        
                // console.log(req.body.name)
        
                const project_id=req.body.projectid;
        
                const project_name=req.body.projectname;
        
                const project_manager=req.body.projectmanager;
        
              
        
           
        
               let query   = `INSERT INTO projectdetails ( id, projectid, projectname, projectmanager) VALUES ("${emp_id}", "${project_id}", "${project_name}", "${project_manager}")`;
        
                connection.query(query,(err,result)=>{
        
                  if(err) throw err
        
                  res.json(result)
        
                })
        
        
        
              })







      app.listen('8080',()=>{
          console.log ("server connected to port 8080")
      })



      ////Authetication  

//       var session  = require('express-session');
//       var cookieParser = require('cookie-parser');
//       var morgan = require('morgan');
//       var passport = require('passport');
//       var flash    = require('connect-flash');

//       app.use(morgan('dev')); // log every request to the console
// app.use(cookieParser()); // read cookies (needed for auth)
// app.use(bodyParser.urlencoded({
// 	extended: true
// }));
// app.use(bodyParser.json());


// app.use(session({
// 	secret: 'running',
// 	resave: true,
// 	saveUninitialized: true
//  } )); // session secret
// app.use(passport.initialize());
// app.use(passport.session()); // persistent login sessions
// app.use(flash()); // use connect-flash for flash messages stored in session

